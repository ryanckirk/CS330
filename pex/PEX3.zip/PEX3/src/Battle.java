import javax.swing.*;
import java.awt.*;
import java.util.*;

import static javax.swing.JOptionPane.*;

/**
 * CS 330 - Mini-Massive - Phase 1
 *
 * large-scale autonomous life simulation along the lines of the Massive software first developed for The Lord of
 * the Rings software and subsequently used in many applications. (See http://www.massivesoftware.com/index.html).
 *
 * @author  Ryan Kirk
 * @date    10/25/1998
 *
 */

/**
 * This is the Battle Class that takes input from the GUI.
 * This is where the simulation is run, and the simulation window is drawn.
 */
public class Battle {
    /**
     * this is where various variables are created. They are updated by the GUI when the simulation is run.
     */

    private static final int BLUE_ARMY_SIZE = 50;
    private static final int RED_ARMY_SIZE = 50;
    private static final int ORANGE_ARMY_SIZE = 50;
    private static final int GREEN_ARMY_SIZE = 50;

    double blueCourage = 1.5;
    double blueStrength = 1.5;
    double blueSpeed = 1.5;

    double redCourage = 1.5;
    double redStrength = 1.5;
    double redSpeed = 1.5;
    double redSpeedUp = 0.0;
    double redArmySpeedSelected;

    double orangeCourage = 1.5;
    double orangeStrength = 1.5;
    double orangeSpeed = 1.5;

    double greenCourage = 1.5;
    double greenStrength = 1.5;
    double greenSpeed = 1.5;

    int orangeAdvisaryBat = 0;
    int greenAdvisaryBat = 0;




    private static final int WINDOW_WIDTH = 800;
    private static final int WINDOW_HEIGHT = 600;
    private static final int TIME_STEP = 50;
    DrawingPanel panel = new DrawingPanel( WINDOW_WIDTH, WINDOW_HEIGHT );
    private boolean pause = false;

     boolean closeWindow = false;
    boolean runSim = true;
    boolean pauseButton = false;

     int numArmies = 3;
     int numArmiesSelected;

    /**
     *  Zero-argument constructor
     */
    public Battle() {
    }



    /**
     * Creates two armies and has them interact in a battle.
     */
    public void doBattle() {
        numArmies = getNumArmiesSelected();
        //updateParameterVal();
        //redSpeed = updateParameterVal();
        //redSpeed = getRedArmySpeed();

        // set up the DrawingPanel and Graphics2D objects

        //DrawingPanel panel = new DrawingPanel( WINDOW_WIDTH, WINDOW_HEIGHT );
        panel.setWindowTitle("CS330 Mini-Massive Reference Solution");

        Graphics2D g = panel.getGraphics();
        panel.setBackground( Color.LIGHT_GRAY );

        // connect Army and Warrior classes to graphics display

        Army.setGraphics(g);
        Army.setScreenWidth(WINDOW_WIDTH);
        Army.setScreenHeight(WINDOW_HEIGHT);

        Warrior.setGraphics(g);
        Warrior.setScreenWidth(WINDOW_WIDTH);
        Warrior.setScreenHeight(WINDOW_HEIGHT);

        // Create the two armies


        Army blueArmy = new Army( BLUE_ARMY_SIZE, Army.LEFT_SIDE,
                blueSpeed, 10, Color.BLUE, blueCourage, blueStrength, false );
        Army redArmy = new Army( RED_ARMY_SIZE, Army.RIGHT_SIDE,
                redSpeed, 6, Color.RED, redCourage, redStrength, true );
        Army orangeArmy = new Army( ORANGE_ARMY_SIZE, Army.TOP_SIDE,
                orangeSpeed, 10, Color.ORANGE, orangeCourage, orangeStrength, false );
        Army greenArmy = new Army( GREEN_ARMY_SIZE, Army.BOTTOM_SIDE,
                greenSpeed, 10, Color.GREEN, greenCourage, greenStrength, true );

        // set the armies as adversaries


        blueArmy.setAdversary(redArmy);
        redArmy.setAdversary(blueArmy);
        orangeArmy.setAdversary(greenArmy);
        greenArmy.setAdversary(orangeArmy);

        // have armies draw themselves

        blueArmy.draw();
        redArmy.draw();
        if (numArmies == 3){
            if (orangeAdvisaryBat==0) {
                Random rand = new Random();

                int randInt = rand.nextInt(10);

                if (randInt % 2 == 0) {
                    orangeArmy.setAdversary(redArmy);
                } else {
                    orangeArmy.setAdversary(blueArmy);
                }
            }
            else{
                if (orangeAdvisaryBat==1){
                    orangeArmy.setAdversary(redArmy);
                }
                else {
                    orangeArmy.setAdversary(blueArmy);
                }
            }
            orangeArmy.draw();


        }
        if (numArmies == 4){
            orangeArmy.draw();
            greenArmy.draw();
            if (orangeAdvisaryBat!=0){
                if (orangeAdvisaryBat ==1){
                    orangeArmy.setAdversary(redArmy);
                }
                if (orangeAdvisaryBat ==2){
                    orangeArmy.setAdversary(blueArmy);
                }
                if (orangeAdvisaryBat==3){
                    orangeArmy.setAdversary(greenArmy);
                }
            }
            else{
                orangeArmy.setAdversary(greenArmy);
            }

            if (greenAdvisaryBat!=0){
                if (greenAdvisaryBat ==1){
                    greenArmy.setAdversary(redArmy);
                }
                if (greenAdvisaryBat ==2){
                    greenArmy.setAdversary(blueArmy);
                }
                if (orangeAdvisaryBat==3){
                    greenArmy.setAdversary(orangeArmy);
                }
            }
            else{
                greenArmy.setAdversary(orangeArmy);
            }


        }



        panel.setWindowTitle("CS330 PEX2 Mini-Massive Reference Solution (Space key to pause/resume. Left-click to end)");

        panel.copyGraphicsToScreen();

        // prompt the user to begin the battle

        //JOptionPane.showMessageDialog( null, "Let's get ready to RUMBLE!!!","Mini-Massive", INFORMATION_MESSAGE );

        // animate the battle
        int numBlue = blueArmy.count();
        int numRed = redArmy.count();
        int numOrange = orangeArmy.count();
        int numGreen = greenArmy.count();
        boolean oneReamin = false;
        boolean blueZero = false;
        boolean redZero = false;
        boolean orangeZero = false;
        boolean greenZero = false;
        int winner = -1;




        //((!panel.mouseClickHasOccurred( DrawingPanel.LEFT_BUTTON))((numBlue!=0)&&(numRed!=0)&&(numGreen!=0)&&numOrange!=0))
        while ((((!panel.mouseClickHasOccurred( DrawingPanel.LEFT_BUTTON))||!oneReamin)&&runSim)) {

            if (panel.keyHasBeenHit(DrawingPanel.SPACE_KEY)) pause = !pause;

            if (!pause&&!pauseButton) {

                // clear last scene

                panel.setBackground(Color.LIGHT_GRAY);

                if (numArmies == 2) {

                    // move each army's warriors

                    blueArmy.move();
                    redArmy.move();

                    // update to their next position (from move())

                    blueArmy.updateToNextPosition();
                    redArmy.updateToNextPosition();

                    // have warriors fight at their new positions

                    blueArmy.fight();
                    redArmy.fight();

                    // draw each army in new positions

                    blueArmy.draw();
                    redArmy.draw();
                    numBlue = blueArmy.count();
                    numRed = redArmy.count();
                    orangeZero = true;
                    greenZero = true;

                    panel.setWindowTitle("CS330 PEX2 Mini-Massive Reference Solution - Blue: " + numBlue +
                            ", Red: " + numRed + " (Space key to pause/resume. Left-click to end)");
                    if (numBlue ==0){
                        oneReamin = true;
                        winner = 1;
                        runSim = false;
                    }
                    if (numRed== 0){
                        oneReamin = true;
                        winner = 0;
                        runSim = false;
                    }
                }
                if (numArmies == 3) {

                    blueArmy.move();
                    redArmy.move();
                    orangeArmy.move();
                    blueArmy.updateToNextPosition();
                    redArmy.updateToNextPosition();
                    orangeArmy.updateToNextPosition();
                    blueArmy.fight();
                    redArmy.fight();
                    orangeArmy.fight();
                    blueArmy.draw();
                    redArmy.draw();
                    orangeArmy.draw();
                    numBlue = blueArmy.count();
                    numRed = redArmy.count();
                    numOrange = orangeArmy.count();
                    orangeZero = false;

                    panel.setWindowTitle("CS330 PEX2 Mini-Massive Reference Solution - Blue: " + numBlue +
                            ", Red: " + numRed + ", Orange: " + numOrange+" (Space key to pause/resume. Left-click to end)");
                    if (numBlue==0){
                        redArmy.setAdversary(orangeArmy);
                        orangeArmy.setAdversary(redArmy);
                        if (numRed==0 || numOrange ==0){
                            oneReamin = true;
                        }
                    }
                    if (numRed==0){
                        blueArmy.setAdversary(orangeArmy);
                        orangeArmy.setAdversary(blueArmy);
                        if (numBlue == 0 || numOrange==0){
                            oneReamin = true;
                        }
                    }
                    if (numBlue ==0 && numRed==0){
                        //orange wins
                        winner = 2;
                        runSim = false;
                    }
                    if (numBlue==0 && numOrange ==0){
                        //red wins
                        winner = 1;
                        runSim = false;
                    }
                    if (numRed==0 &&numOrange==0){
                        //blue wins
                        winner = 0;
                        runSim = false;
                    }



                }
                if (numArmies == 4) {

                    blueArmy.move();
                    redArmy.move();
                    orangeArmy.move();
                    greenArmy.move();
                    blueArmy.updateToNextPosition();
                    redArmy.updateToNextPosition();
                    orangeArmy.updateToNextPosition();
                    greenArmy.updateToNextPosition();
                    blueArmy.fight();
                    redArmy.fight();
                    orangeArmy.fight();
                    greenArmy.fight();
                    blueArmy.draw();
                    redArmy.draw();
                    orangeArmy.draw();
                    greenArmy.draw();
                    numBlue = blueArmy.count();
                    numRed = redArmy.count();
                    numOrange = orangeArmy.count();
                    numGreen = greenArmy.count();
                    //greenZero = false;

                    panel.setWindowTitle("CS330 PEX2 Mini-Massive Reference Solution - Blue: " + numBlue +
                            ", Red: " + numRed + ", Orange: " + numOrange+ ", Green: " +
                            numGreen +" (Space key to pause/resume. Left-click to end)");
                    Random rand = new Random();
                    int randInt = rand.nextInt(10);



                    if (numBlue==0){
                        blueZero = true;
                        if (randInt%2 == 0){
                            if (!orangeZero){
                                redArmy.setAdversary(orangeArmy);
                            }
                            else {
                                redArmy.setAdversary(greenArmy);
                            }

                        }
                        else{
                            if (!greenZero){
                                redArmy.setAdversary(greenArmy);
                            }
                            else{
                                redArmy.setAdversary(orangeArmy);
                            }
                        }

                    }
                    if (numRed==0){
                        redZero = true;
                        if (randInt%2 == 0){
                            if (!orangeZero){
                                blueArmy.setAdversary(orangeArmy);
                            }
                            else {
                                blueArmy.setAdversary(greenArmy);
                            }

                        }
                        else{
                            if (!greenZero){
                                blueArmy.setAdversary(greenArmy);
                            }
                            else{
                                blueArmy.setAdversary(orangeArmy);
                            }
                        }
                    }
                    //GrenWIns
                    if (numOrange==0){
                        orangeZero = true;
                        if (randInt%2 == 0){
                            if (!redZero){
                                greenArmy.setAdversary(redArmy);
                            }
                            else {
                                greenArmy.setAdversary(blueArmy);
                            }

                        }
                        else{
                            if (!blueZero){
                                greenArmy.setAdversary(blueArmy);
                            }
                            else{
                                greenArmy.setAdversary(redArmy);
                            }
                        }
                    }
                    if (numGreen == 0){
                        greenZero = true;
                        if (randInt%2 == 0){
                            if (!redZero){
                                orangeArmy.setAdversary(redArmy);
                            }
                            else {
                                orangeArmy.setAdversary(blueArmy);
                            }

                        }
                        else{
                            if (!blueZero){
                                orangeArmy.setAdversary(blueArmy);
                            }
                            else{
                                orangeArmy.setAdversary(redArmy);
                            }
                        }
                    }
                    ///////////////////////////////////////////////////////////////////////////////////////////////////////////
                    if (blueZero&&redZero&&orangeZero){
                        //green wins
                        winner = 3;
                        runSim =true;
                    }
                    if (blueZero&&redZero&&greenZero){
                        //orange wins
                        winner = 2;
                        runSim = false;
                    }
                    if (blueZero&&orangeZero&&greenZero){
                        //red wins
                        winner = 1;
                        runSim = false;
                    }
                    if (redZero&&orangeZero&&greenZero){
                        //blue wins
                        winner = 0;
                        runSim = false;
                    }

                    //Green Wins





                }

                if (pauseButton){
                    panel.setWindowTitle("PAUSE");
                }

            } // end of if not paused

            panel.sleep( TIME_STEP ); // pause to pace the animation
            panel.copyGraphicsToScreen();  // update the graphics
            //Find new enemies

            if (closeWindow){
                panel.closeWindow();
            }


        }
        switch (winner){
            case 0:
                g.drawString("Blue team wins!!",250,250);
                break;
            case 1:
                g.drawString("Red team wins!!",250,250);
                break;
            case 2:
                g.drawString("Orange team wins!!",250,250);
                break;
            case 3:
                g.drawString("Green team wins!!",250,250);
                break;
        }
/*
        if(numBlue>numRed){
            //prints to the display the winning team
            g.drawString("Blue team wins!!",250,250);


        }
        else{
            //panel.setBackground(Color.RED);
            g.drawString("Red team wins!!",250,250);
        }
        */

        g.drawString("Click to exit",250,450);
        panel.copyGraphicsToScreen();
        //waits for the user to click to end the simulation

        while (!panel.mouseClickHasOccurred(DrawingPanel.LEFT_BUTTON)||closeWindow){        }

        panel.closeWindow();  // all done

    } // end main() method

    /**
     * Closes the battle window if the function is called from the GUI
     */

    public void closeBattle(){
        //closeWindow = true;
        runSim = false;
        panel.closeWindow();



    }

    /**
     * Pausses the battle.
     * Uses the pause functionality from PEX 2. Uses the GUI to pause instead of the space bar
     */
    public void pauseBattle(){
        if (pauseButton){
            pauseButton = false;
        }
        else{
            pauseButton = true;
        }


    }

    /**
     * Function to set the number of armies that have ben seledcted when the simulation is run.
     * Takes an input from the GUI
     * @param armiesGUI
     */
    public void setNumArmies(int armiesGUI){
        numArmiesSelected = armiesGUI;
    }

    /**
     * Returns the number of armies selected. Allows the variable to updated in the battle class doBattle function
     * @return
     */
    public int getNumArmiesSelected(){
        return numArmiesSelected;

    }
    public double newParameterVal(double newVal){
        return newVal;
    }
    public void setRedArmySpeed(double selectedGUI){
        redArmySpeedSelected = selectedGUI;
    }

    public double getRedArmySpeed(){
        return redArmySpeedSelected;
    }

    public void updateNumArmies(){

    }

    /**
     * Ended up having this functionality in the GUI.
     * Essentialy sees what army and parameter is selected, and then updates the value based on the slider position.
     * @param army
     * @param parameter
     * @param val
     */
    public void updateParameter(int army, int parameter, double val){
        switch (army){
            case(1)://Red
                switch (parameter){
                    case (0)://Courage
                        redCourage = val;
                        break;
                    case (1)://Strength
                        redStrength = val;
                        break;
                    case (2)://Speed
                        //redSpeed = val*10;
                        redSpeedUp = val;
                        updateParameterVal(val);
                        break;
                }
                //
                break;
            case(2)://Blue
                switch (parameter){
                    case (0)://Courage
                        blueCourage = val;
                        break;
                    case (1)://Strength
                        blueStrength = val;
                        break;
                    case (2)://Speed
                        blueSpeed = val;
                        break;
                }
                break;
            case(3)://Orange
                switch (parameter){
                    case (0)://Courage
                        orangeCourage = val;
                        break;
                    case (1)://Strength
                        orangeStrength = val;
                        break;
                    case (2)://Speed
                        orangeSpeed = val;
                        break;
                }
                break;
            case(4)://Green
                switch (parameter){
                    case (0)://Courage
                        greenCourage = val;
                        break;
                    case (1)://Strength
                        greenStrength = val;
                        break;
                    case (2)://Speed
                        greenSpeed = val;
                        break;
                }
                break;

        }

    }

    void updateParameterVal(double val){
        //return redSpeedUp;
        redSpeedUp = val;

    }

}  // end Battle class

