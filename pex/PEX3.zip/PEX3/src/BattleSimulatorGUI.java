import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
/**
 * @author Ryan Kirk
 */

/**
 *
 * This is my Battle Simulator GUI
 * It uses Dr. Hadfield's Pex  2 solution at the back end for the battle simulation
 * I had to make a few changes for it work with the backend and be able to display the winner at the end of the simulation.
 * I will do my best to comment the code within, but be warned... this code is not pretty to look at :)
 *
 */
public class BattleSimulatorGUI extends Thread {

    //private static Battle myBat;
    private JButton startButton;
    private JButton endButton;
    private JButton pauseButton;

    private JPanel myPanel;
    private JComboBox parameterSelector;
    private JButton addArmy;
    private JButton deleteArmy;
    private JSlider parameterSlider;
    private JButton Update;
    private JTextArea valueHolder;
    private JComboBox armySelector;
    private JTextField armySelectedVal;
    private JTextField parameterSelectedVal;
    private JTextField sliderCurrentValBox;
    private JButton updateButton;
    private JTextArea textArea1;
    private JComboBox selectAdvisary;
    private JTextField SELECTPARAMETERBELOWTextField;
    private JTextArea SELECTADVISARYFORARMIESTextArea;
    private Battle myBat;
    String[] armyStrings = {"Red Army", "Blue Army", "Orange Army", "Green Army"};

    /**
     * Below is a series of variables that help support the GUI functionality and implementing it in the situation.
     * Some are unused, but I am too afraid to delete any of them.
     */
    int status = 0;
    int numTeams = 2;
    boolean simPaused = false;
    int numberOfArmies = 2;

    boolean changeArmies = false;
    int armySelected = 1;
    int parameterSelected = 0;
    int parameterVal = 15;

    double soldierParameterVal = 1.5;

    int selectedAdvisaryGUI = 0;


    double blueCourageGUI = 1.5;
    double blueStrengthGUI = 1.5;
    double blueSpeedGUI = 1.5;

    double redCourageGUI = 1.5;
    double redStrengthGUI = 1.5;
    double redSpeedGUI = 1.5;
    double redSpeedUpGUI = 0.0;
    double redArmySpeedSelected;

    double orangeCourageGUI = 1.5;
    double orangeStrengthGUI = 1.5;
    double orangeSpeedGUI = 1.5;

    double greenCourageGUI = 1.5;
    double greenStrengthGUI = 1.5;
    double greenSpeedGUI = 1.5;

    int orangeTarget = 0;
    int greenTarget = 0;

    /**
     * This is the method that runs the entire simulation GUI
     * It creates a new thread for the simulation so the GUI and the Simulation can run simultainiusly.
     * A new battle is object is created at the start of the GUI.
     */
    public BattleSimulatorGUI() {
        myBat = new Battle();
        pauseButton.setEnabled(false);
        addArmy.setEnabled(true);
        deleteArmy.setEnabled(false);
        valueHolder.setText("Num Armies: " + numberOfArmies);

        endButton.addActionListener(new ActionListener() {

            @Override
            /**
             * Closes all the Jframe/Windows when the end button is pressed.
             */
            public void actionPerformed(ActionEvent actionEvent) {

                myBat.closeWindow = true;
                System.exit(0);

            }
        });

        pauseButton.addActionListener(new ActionListener() {
            @Override
            /**
             * Button to pause the simulation. Uses the pause functionality from the battle class.
             */
            public void actionPerformed(ActionEvent actionEvent) {
                if (!simPaused) {
                    simPaused = true;
                    myBat.pauseBattle();
                    //myBat.closeBattle();

                    pauseButton.setText("Un-Pause");
                } else {
                    simPaused = false;
                    myBat.pauseBattle();
                    pauseButton.setText("Pause");

                }

                //myBat.pauseBattle();


            }
        });
        startButton.addActionListener(new ActionListener() {
            @Override
            /**
             * Starts the simulation. If a simulation is currently running, a new simulation is started.
             * Sets inital values of the armies parameters based off of GUI inputs.
             */
            public void actionPerformed(ActionEvent actionEvent) {
                if (startButton.getText().equals("Re-Start Sim")) {
                    myBat.closeBattle();
                }
                myBat = new Battle();
                status = 3;
                Thread t = new Thread() {
                    public void run() {
                        try {
                            myBat.setNumArmies(numberOfArmies);
                            myBat.blueSpeed = blueSpeedGUI;
                            myBat.blueStrength = blueStrengthGUI;
                            myBat.blueCourage = blueCourageGUI;

                            myBat.redSpeed = redSpeedGUI;
                            myBat.redStrength = redStrengthGUI;
                            myBat.redCourage = redCourageGUI;

                            myBat.orangeSpeed = orangeSpeedGUI;
                            myBat.orangeStrength = orangeStrengthGUI;
                            myBat.orangeCourage = orangeCourageGUI;

                            myBat.greenSpeed = greenSpeedGUI;
                            myBat.greenStrength = greenStrengthGUI;
                            myBat.greenCourage = greenCourageGUI;
                            myBat.orangeAdvisaryBat = orangeTarget;
                            myBat.greenAdvisaryBat = greenTarget;

                            myBat.doBattle();


                            sleep(10);
                        } catch (InterruptedException ex) {
                        }
                    }
                };
                t.start();
                startButton.setText("Re-Start Sim");
                status = 1;
                pauseButton.setEnabled(true);
                if (simPaused) {
                    pauseButton.setText("Pause Sim");
                }

            }
        });


        ////////////////////////////COMBO BOX///////////////

        parameterSelector.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {

            }
        });

        addArmy.addActionListener(new ActionListener() {
            @Override
            /**
             * Buttons to allow for the third and fourth armies to be added.
             * Logic makes sure the simulation never has more than 4 armies or less than 2 armies.
             * Buttons become enabled as they are available to use
             * Adds armies to the parameter selector as they become available.
             */
            public void actionPerformed(ActionEvent actionEvent) {
                if (((numberOfArmies > 1) && numberOfArmies < 4)) {
                    numberOfArmies++;
                    valueHolder.setText("Num Armies: " + numberOfArmies);
                    //addArmy.setEnabled(true);
                }
                if (numberOfArmies > 2) {
                    deleteArmy.setEnabled(true);
                }
                if (numberOfArmies > 3) {
                    addArmy.setEnabled(false);
                }
                if (numberOfArmies == 3) {
                    armySelector.removeAllItems();
                    armySelector.addItem("Red Army");
                    armySelector.addItem("Blue Army");
                    armySelector.addItem("Orange Army");

                    selectAdvisary.removeAllItems();
                    selectAdvisary.addItem("Red Army");
                    selectAdvisary.addItem("Blue Army");

                    //armySelector.add
                }
                if (numberOfArmies == 4) {
                    armySelector.removeAllItems();
                    armySelector.addItem("Red Army");
                    armySelector.addItem("Blue Army");
                    armySelector.addItem("Orange Army");
                    armySelector.addItem("Green Army");

                    selectAdvisary.removeAllItems();
                    selectAdvisary.addItem("Red Army");
                    selectAdvisary.addItem("Blue Army");
                    selectAdvisary.addItem("Orange Army");


                }

            }
        });
        deleteArmy.addActionListener(new ActionListener() {
            @Override
            /**
             * Deletes the third and fourth army. Makes sure the buttons function as expected given the amount of armies.
             * Takes away armies from the parameter selectors as they no longer are in the battle.
             */
            public void actionPerformed(ActionEvent actionEvent) {
                if ((numberOfArmies > 2) && numberOfArmies < 5) {
                    numberOfArmies = numberOfArmies - 1;
                    //deleteArmy.setEnabled(true);
                    valueHolder.setText("Num Armies: " + numberOfArmies);

                }
                if (numberOfArmies > 2 && numberOfArmies < 4) {
                    //deleteArmy.setEnabled(false);
                } else {
                    deleteArmy.setEnabled(false);
                }
                if (numberOfArmies > 1) {
                    addArmy.setEnabled(true);
                }
                if (numberOfArmies == 3) {
                    armySelector.removeAllItems();
                    armySelector.addItem("Red Army");
                    armySelector.addItem("Blue Army");
                    armySelector.addItem("Orange Army");
                }
                if (numberOfArmies == 2) {
                    armySelector.removeAllItems();
                    armySelector.addItem("Red Army");
                    armySelector.addItem("Blue Army");

                }
            }
        });

        armySelector.addActionListener(new ActionListener() {
            @Override
            /**
             * army selector sees which of the four armies are selected.
             * This value is used to update the armies parameters when the update button is pushed
             */
            public void actionPerformed(ActionEvent actionEvent) {
                armySelected = armySelector.getSelectedIndex() + 1;
                switch (armySelected) {
                    case 1:
                        armySelectedVal.setText("Selected Army: Red Army");
                        break;
                    case 2:
                        armySelectedVal.setText("Selected Army: Blue Army");
                        break;
                    case 3:
                        armySelectedVal.setText("Selected Army: Orange Army");
                        break;
                    case 4:
                        armySelectedVal.setText("Selected Army: Green Army");
                        break;
                }


            }
        });
        parameterSelector.addActionListener(new ActionListener() {
            @Override
            /**
             * Selects which of the three parameters to be updated (Courage, Strength, Speed).
             * This is used to update a selected armies selected parameters when update is pressed.
             */
            public void actionPerformed(ActionEvent actionEvent) {
                parameterSelected = parameterSelector.getSelectedIndex();

                switch (parameterSelected) {
                    case 0:
                        parameterSelectedVal.setText("Selected Parameter: Courage");
                        break;
                    case 1:
                        parameterSelectedVal.setText("Selected Parameter: Strength");
                        break;
                    case 2:
                        parameterSelectedVal.setText("Selected Parameter: Speed");
                        break;

                }
            }
        });

        parameterSlider.addChangeListener(new ChangeListener() {
            @Override
            /**
             * This creates the update parameter value.
             * The slider has a range of 1 to 30. The value of the slider is divided by 10 so the range of parameters can
             * be a double from 0.1 to 3.0
             */
            public void stateChanged(ChangeEvent changeEvent) {
                soldierParameterVal = (double) parameterSlider.getValue() / 10;
                sliderCurrentValBox.setText("Parameter Power: " + soldierParameterVal);


            }
        });

        updateButton.addActionListener(new ActionListener() {
            @Override
            /**
             * This is the function that drives the parameters updating and the advisary selector.
             * When the button is pressed, it takes all the cached values that have been inputted, and assigns them to variables.
             * When the simulation is run or rerun, all of the values are inputted into the simulation.
             */
            public void actionPerformed(ActionEvent actionEvent) {
                //myBat.updateParameter(armySelected, parameterSelected, soldierParameterVal);
                //myBat.setRedArmySpeed(soldierParameterVal);
                switch (armySelected) {
                    case (1)://Red
                        switch (parameterSelected) {
                            case (0)://Courage
                                redCourageGUI = soldierParameterVal;
                                break;
                            case (1)://Strength
                                redStrengthGUI = soldierParameterVal;
                                break;
                            case (2)://Speed
                                //redSpeed = val*10;
                                redSpeedGUI = soldierParameterVal;
                                break;
                        }
                        //
                        break;
                    case (2)://Blue
                        switch (parameterSelected) {
                            case (0)://Courage
                                blueCourageGUI = soldierParameterVal;
                                break;
                            case (1)://Strength
                                blueStrengthGUI = soldierParameterVal;
                                break;
                            case (2)://Speed
                                blueSpeedGUI = soldierParameterVal;
                                break;
                        }
                        break;
                    case (3)://Orange
                        switch (parameterSelected) {
                            case (0)://Courage
                                orangeCourageGUI = soldierParameterVal;
                                break;
                            case (1)://Strength
                                orangeStrengthGUI = soldierParameterVal;
                                break;
                            case (2)://Speed
                                orangeSpeedGUI = soldierParameterVal;
                                break;
                        }
                        break;
                    case (4)://Green
                        switch (parameterSelected) {
                            case (0)://Courage
                                greenCourageGUI = soldierParameterVal;
                                break;
                            case (1)://Strength
                                greenStrengthGUI = soldierParameterVal;
                                break;
                            case (2)://Speed
                                greenSpeedGUI = soldierParameterVal;
                                break;
                        }
                        break;

                }

                if (numberOfArmies == 3) {
                    if (selectedAdvisaryGUI == 1) {
                        //
                        orangeTarget = 1;
                    } else {
                        orangeTarget = 2;

                    }
                }
                if (numberOfArmies == 4) {
                    if (selectedAdvisaryGUI == 1) {
                        greenTarget = 1;
                    }
                    if (selectedAdvisaryGUI == 2) {
                        greenTarget = 2;
                    }
                    if (selectedAdvisaryGUI == 3) {
                        greenTarget = 3;
                    }
                }


            }
        });

        selectAdvisary.addActionListener(new ActionListener() {
            @Override
            /**
             * Advisary selection. The third and fourth armies can have their advisaries set automaticaly.
             * If it is not set automatically, it defaults to a random val.
             */
            public void actionPerformed(ActionEvent actionEvent) {
                if (selectAdvisary.getSelectedIndex() == 0) {
                    //red army
                    selectedAdvisaryGUI = 1;
                } else {
                    selectedAdvisaryGUI = 2;
                    //blue army
                }
            }
        });


        //parameterSlider.getVa


        //////////////////////////////////////////////////////////
        if ((numberOfArmies > 1) && (numberOfArmies < 3)) {
            addArmy.setEnabled(true);
        } else {
            addArmy.setEnabled(false);
        }
        armySelector.addItem("Red Army");
        armySelector.addItem("Blue Army");
        //armySelector.addItem("Orange Army");
        //armySelector.addItem("Green Army");
        armySelector.setSelectedIndex(0);

        ///COURAGE STRENGTH SPEED//
        parameterSelector.addItem("Courage");
        parameterSelector.addItem("Strength");
        parameterSelector.addItem("Speed");
        parameterSelector.setSelectedIndex(0);

        sliderCurrentValBox.setText("Parameter Power: " + soldierParameterVal);

    }

    /**
     * This is the main function for the entire simulation.
     * It creates the Jframe and the BattleSImulatorGUI object.
     * It is the real meat and potatoes of the whole opperation.
     * @param args
     */
    public static void main(String[] args) {
        //myBat = new Battle();
        JFrame frame = new JFrame("BattleSimG.U.I");
        frame.setContentPane(new BattleSimulatorGUI().myPanel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);


    }


    {
// GUI initializer generated by IntelliJ IDEA GUI Designer
// >>> IMPORTANT!! <<<
// DO NOT EDIT OR ADD ANY CODE HERE!
        $$$setupUI$$$();
    }

    /**
     * Method generated by IntelliJ IDEA GUI Designer
     * >>> IMPORTANT!! <<<
     * DO NOT edit this method OR call it in your code!
     *
     * @noinspection ALL
     */
    private void $$$setupUI$$$() {
        myPanel = new JPanel();
        myPanel.setLayout(new com.intellij.uiDesigner.core.GridLayoutManager(9, 4, new Insets(0, 0, 0, 0), -1, -1));
        startButton = new JButton();
        startButton.setText("Start");
        myPanel.add(startButton, new com.intellij.uiDesigner.core.GridConstraints(0, 0, 1, 2, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        final com.intellij.uiDesigner.core.Spacer spacer1 = new com.intellij.uiDesigner.core.Spacer();
        myPanel.add(spacer1, new com.intellij.uiDesigner.core.GridConstraints(1, 1, 8, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_VERTICAL, 1, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW, null, null, null, 0, false));
        endButton = new JButton();
        endButton.setText("End");
        myPanel.add(endButton, new com.intellij.uiDesigner.core.GridConstraints(0, 3, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        pauseButton = new JButton();
        pauseButton.setText("Pause");
        myPanel.add(pauseButton, new com.intellij.uiDesigner.core.GridConstraints(0, 2, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        deleteArmy = new JButton();
        deleteArmy.setText("Delete Army");
        myPanel.add(deleteArmy, new com.intellij.uiDesigner.core.GridConstraints(2, 3, 2, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        addArmy = new JButton();
        addArmy.setText("Add Army");
        myPanel.add(addArmy, new com.intellij.uiDesigner.core.GridConstraints(3, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        valueHolder = new JTextArea();
        myPanel.add(valueHolder, new com.intellij.uiDesigner.core.GridConstraints(2, 2, 2, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_BOTH, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW, null, new Dimension(150, 50), null, 0, false));
        final com.intellij.uiDesigner.core.Spacer spacer2 = new com.intellij.uiDesigner.core.Spacer();
        myPanel.add(spacer2, new com.intellij.uiDesigner.core.GridConstraints(4, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_VERTICAL, 1, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW, null, null, null, 0, false));
        parameterSelector = new JComboBox();
        myPanel.add(parameterSelector, new com.intellij.uiDesigner.core.GridConstraints(5, 2, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        armySelector = new JComboBox();
        myPanel.add(armySelector, new com.intellij.uiDesigner.core.GridConstraints(5, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        armySelectedVal = new JTextField();
        myPanel.add(armySelectedVal, new com.intellij.uiDesigner.core.GridConstraints(5, 3, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, new Dimension(150, -1), null, 0, false));
        parameterSelectedVal = new JTextField();
        myPanel.add(parameterSelectedVal, new com.intellij.uiDesigner.core.GridConstraints(8, 3, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, new Dimension(150, -1), null, 0, false));
        parameterSlider = new JSlider();
        parameterSlider.setMaximum(30);
        parameterSlider.setPaintLabels(true);
        parameterSlider.setPaintTicks(true);
        parameterSlider.setValue(15);
        myPanel.add(parameterSlider, new com.intellij.uiDesigner.core.GridConstraints(6, 0, 2, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        sliderCurrentValBox = new JTextField();
        myPanel.add(sliderCurrentValBox, new com.intellij.uiDesigner.core.GridConstraints(8, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, new Dimension(150, -1), null, 0, false));
        updateButton = new JButton();
        updateButton.setText("Update");
        myPanel.add(updateButton, new com.intellij.uiDesigner.core.GridConstraints(8, 2, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        textArea1 = new JTextArea();
        myPanel.add(textArea1, new com.intellij.uiDesigner.core.GridConstraints(2, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_BOTH, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW, null, new Dimension(150, 50), null, 0, false));
        selectAdvisary = new JComboBox();
        myPanel.add(selectAdvisary, new com.intellij.uiDesigner.core.GridConstraints(6, 2, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        SELECTPARAMETERBELOWTextField = new JTextField();
        SELECTPARAMETERBELOWTextField.setEditable(false);
        SELECTPARAMETERBELOWTextField.setText("SELECT PARAMETER BELOW");
        myPanel.add(SELECTPARAMETERBELOWTextField, new com.intellij.uiDesigner.core.GridConstraints(4, 2, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, new Dimension(150, -1), null, 0, false));
        SELECTADVISARYFORARMIESTextArea = new JTextArea();
        SELECTADVISARYFORARMIESTextArea.setEditable(false);
        SELECTADVISARYFORARMIESTextArea.setText("<--SELECT ADVISARY FOR ARMIES 3 AND 4");
        myPanel.add(SELECTADVISARYFORARMIESTextArea, new com.intellij.uiDesigner.core.GridConstraints(6, 3, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_BOTH, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW, null, new Dimension(150, 50), null, 0, false));
    }

    /**
     * @noinspection ALL
     */
    public JComponent $$$getRootComponent$$$() {
        return myPanel;
    }

}