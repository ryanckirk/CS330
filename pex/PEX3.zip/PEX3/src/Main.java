/**
 * Main - CS 330 - Mini-Massive - Phase 1
 *
 * large-scale autonomous life simulation along the lines of the Massive software first developed for The Lord of
 * the Rings software and subsequently used in many applications. (See http://www.massivesoftware.com/index.html).
 *
 * @author  Steve Hadfield
 * @date    7 Sep 2019
 */
public class Main {

    public static void main(String[] args) {

        Battle battle = new Battle();   // create a new Battle object
        battle.doBattle();              // commence the battle

    }
}
